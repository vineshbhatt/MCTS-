import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-correspondence',
  templateUrl: './create-correspondence.component.html'
})
export class CreateCorrespondenceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
