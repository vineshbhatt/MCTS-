import { Component } from '@angular/core';

@Component({
    selector: 'app-docviewer',
    templateUrl: './documentviewer.component.html'
  })

  export class DocumentViewerComponent {
    // Function to get The DocumenT URL
  }
