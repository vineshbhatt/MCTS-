export class CorrespondenceDetail {
    actualRows: number;
    filteredRows: number;
    myRows: any;
    sourceID: number;
    success: boolean;
    totalRows: number;
    totalSourceRows: number;
  }