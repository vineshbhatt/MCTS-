export class CorrResponse {
    actualRows: string;
    filteredRows: string;
    myRows: any;
    sourceID: string;    
    totalRows: string;
    totalSourceRows: string;
  }