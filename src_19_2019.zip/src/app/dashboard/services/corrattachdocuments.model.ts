export class CorrAttachDocuments {

    CorrespondenceID: number;
    CorrespondenceCoverID: number;
    CorrespondenceCoverURL: String;
    CorrespondenceAttachmentID: number;
    CorrespondenceMiscID: number;
}

