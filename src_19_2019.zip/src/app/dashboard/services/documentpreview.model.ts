export class DocumentPreview {
    
    STATUS: String;
    CorrespondencedocumentURL: String;
    Correspondencedocumentid:number;
       
    }